<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter Native Session Library
 *
 * @package     Sms
 * @subpackage  Libraries
 * @category    Sms
 * @author      Turing
 */

class Smsapidata extends Web
{

    public function getsmsapidata()
    {
        return array('user'=>'aunttsaidorm', 'pass'=>'aunttsai');
    }
}
