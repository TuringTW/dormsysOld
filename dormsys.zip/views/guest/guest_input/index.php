<body oncontextmenu="window.event.returnValue=false;" style="overflow-y: hidden;height:100%" >
	<!-- Change the width and height values to suit you best -->
	<div class="typeform-widget" data-url="https://aunttsaidorm.typeform.com/to/tWEk2z" data-text="Registration Form" style="width:100%;height:90%;position:relative"></div>
	<a href="#" class="btn btn-default" onclick="location.reload();" style="width:10%; left:45%; position:relative">我填完惹</a>

<script>(function(){var qs,js,q,s,d=document,gi=d.getElementById,ce=d.createElement,gt=d.getElementsByTagName,id='typef_orm',b='https://s3-eu-west-1.amazonaws.com/share.typeform.com/';if(!gi.call(d,id)){js=ce.call(d,'script');js.id=id;js.src=b+'widget.js';q=gt.call(d,'script')[0];q.parentNode.insertBefore(js,q)}})()</script>




</body>