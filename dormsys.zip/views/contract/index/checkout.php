<div id="dialog-check-out-comfirm" title="確定要結算嗎?">
	<div class="alert alert-danger"><h2><span class="glyphicon glyphicon-ok"></span>確定要結算嗎?</h2></div>
	<div class="alert alert-warning"><h2><span class="glyphicon glyphicon-star-empty">注意!!!租約到期後，才可開始結算</h2></div>
	<input type="hidden" id="ccontract_id" name="bcontract_id" value="0">
</div>
<div id="dialog-universal-alert" title="通知">
	
</div>


<div id="dialog-keep-comfirm" title="確定要續約嗎?">
	<div class="alert alert-danger"><h2><span class="glyphicon glyphicon-ok"></span>確定要續約嗎?</h2></div>
	<div class="alert alert-warning"><h2><span class="glyphicon glyphicon-star-empty">注意!!!只有在合約到期前三個月可以續約</h2><h2><span class="glyphicon glyphicon-star-empty">續約後會自動把合約丟到待結算合約裡，但在到期前都會顯示為已續約</h2></div>
	<input type="hidden" id="kcontract_id" name="bcontract_id" value="0">
</div>