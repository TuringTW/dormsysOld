
<div class="modal fade " style="z-index:1300" id="printModal" tabindex="-1" role="dialog" data-show="1" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">

				<div class="modal-header">
					<button type="button" id="closebtn" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="myModalLabel">列印合約</h4>
				</div>
				<div class="modal-body">
					<div class="well" style="width:100%; height:500px">
						<iframe src="" id="print_iframe" style="width:100%; height:100%"></iframe>
					</div>
						
    					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>					
				</div>

		</div><!-- /.modal-content -->
		
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->