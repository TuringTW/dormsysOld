<h1 class="page-header">信件總表</h1>
<!-- 搜尋列 次導覽列 -->
	<div class="form-group">
		<div class="col-sm-3">
			<a href="#" class="btn btn-default" onclick="$('#newmailModal').modal('toggle')" >新增信件</a>
		</div>
 	</div>	
	<br>
	<br>
	<hr>
			<!-- 搜尋結果 -->

	<div class="table-responsive">
		<table class="table table-hover" >
			
				<thead>
					<tr>
						<th style="text-align:center; width:5%">#</th>
						<th style="text-align:center; width:15%">收件人姓名</th>
						<th style="text-align:center; width:18%">電話</th>
						<th style="text-align:center; width:7%">再次通知</th>
						<th style="text-align:center; width:10%">類型</th>
						<th style="text-align:center; width:20%">收件時間</th>
						<th style="text-align:center; width:7%">拖延時間</th>
						<th style="text-align:center; width:8%">是否送達?</th>
						<th style="text-align:center; width:5%">刪除</th>
					</tr>
				</thead>
				<tbody id="result_table" style="text-align:center">

				</tbody>
		</table>
	</div>
</div>
</div>
